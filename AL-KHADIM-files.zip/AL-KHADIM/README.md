# AL-KHADIM

Arabic welcome page built with Flask.

## Deploy on Render
1. Upload these files to a GitHub repository.
2. In Render, create a **Web Service** and connect the repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Choose a service name, for example `alkhadim` if available.

The page displays a welcome message. It only sends IP/browser information and a battery percentage (if browser-supported) after the visitor explicitly checks the consent box and clicks the button. The real device name is not exposed by ordinary browsers. IP and device details may be visible in the hosting service logs.

Do not store sensitive data unnecessarily. Hosting providers may sleep or change limits under free plans.
