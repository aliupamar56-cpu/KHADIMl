from flask import Flask, request, render_template_string
from datetime import datetime, timezone
import os
import re

app = Flask(__name__)

PAGE = """
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AL-KHADIM</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0; min-height: 100vh; display: grid; place-items: center;
      background: #0b1020; color: #f8fafc;
      font-family: Arial, sans-serif; padding: 20px;
    }
    .card {
      width: 100%; max-width: 440px; padding: 28px;
      background: #151d30; border: 1px solid #29364e;
      border-radius: 22px; box-shadow: 0 18px 50px #0005;
    }
    h1 { color: #22d3ee; text-align: center; margin-top: 0; }
    h2 { text-align: center; }
    p { line-height: 1.8; color: #dbeafe; }
    label { display: block; line-height: 1.8; margin-top: 14px; }
    button {
      width: 100%; border: 0; border-radius: 12px; padding: 14px;
      margin-top: 18px; background: #0891b2; color: white;
      font-size: 16px; cursor: pointer;
    }
    #msg { min-height: 1.5em; }
  </style>
</head>
<body>
  <main class="card">
    <h1>AL-KHADIM</h1>
    <h2>مرحباً بك في موقعنا 🌟</h2>
    <p>أهلاً وسهلاً بك. إذا اخترت المتابعة، سنرسل إلى مشغّل الموقع عنوان الاتصال
    ونوع المتصفح، ونسبة البطارية فقط إذا كان المتصفح يدعم قراءتها.</p>
    <label><input type="checkbox" id="consent">
      أوافق على إرسال هذه المعلومات إلى مشغّل الموقع.
    </label>
    <button onclick="sendInfo()">موافقة ومتابعة</button>
    <p id="msg" role="status"></p>
  </main>
<script>
async function sendInfo() {
  const msg = document.getElementById('msg');
  if (!document.getElementById('consent').checked) {
    msg.textContent = 'يرجى تحديد الموافقة أولاً.';
    return;
  }
  let battery = 'غير متاحة';
  try {
    if (navigator.getBattery) {
      const b = await navigator.getBattery();
      battery = Math.round(b.level * 100) + '%';
    }
  } catch (_) {}
  const body = new URLSearchParams({
    consent: 'yes',
    device: navigator.userAgent,
    battery: battery
  });
  try {
    const response = await fetch('/submit', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body
    });
    msg.textContent = response.ok
      ? 'تم إرسال المعلومات بنجاح.'
      : 'تعذر إرسال المعلومات.';
  } catch (_) {
    msg.textContent = 'تعذر الاتصال بالخادم. حاول مرة أخرى.';
  }
}
</script>
</body>
</html>
"""

@app.get("/")
def home():
    return render_template_string(PAGE)

@app.post("/submit")
def submit():
    if request.form.get("consent") != "yes":
        return "Consent required", 403

    # Do not trust forwarded headers unless a trusted proxy is configured.
    ip = request.remote_addr or "غير معروف"
    device = request.form.get("device", "غير معروف")[:500]
    battery = request.form.get("battery", "غير متاحة")[:30]
    timestamp = datetime.now(timezone.utc).isoformat()

    # Logs go to the hosting provider's service logs.
    print(
        f"AL-KHADIM visit | time={timestamp} | ip={ip} | "
        f"device={device!r} | battery={battery!r}",
        flush=True
    )
    return {"status": "ok"}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
